﻿namespace SurvivalistsAdditions {

	public enum NotificationType {
		None,
		SilentText,
		TextWithSound,
		Letter
	}
}
