# Survivalist's Additions

Adds new features for a tribal colony or one without power.

![Preview](https://raw.githubusercontent.com/cuproPanda/SRV/master/About/Preview.png)